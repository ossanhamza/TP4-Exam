package com.emsi.orderservice.enums;

public enum OrderStatus {
    CREATED, PENDING, DELIVERED, CANCELLED
}
