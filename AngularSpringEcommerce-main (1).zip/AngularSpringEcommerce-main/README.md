# AngularSpringEcommerce
Activité Pratique N°4 :  Application e-commerce basée sur les Micro-services
# Installer les node modules et angular cli avec les commandes suivantes:
    npm install

    npm run ng serve
# Compte rendu: 
# Customer-service : 
![cust](https://github.com/itsmouhy/AngularSpringEcommerce/assets/100805135/03412128-93e5-458f-85fe-e327360e5e66)

# Inventory-service : 
![prod](https://github.com/itsmouhy/AngularSpringEcommerce/assets/100805135/7b8eb4de-8657-415c-b383-a8f03b0bce0d)

# Order-service : 
![order](https://github.com/itsmouhy/AngularSpringEcommerce/assets/100805135/e30563e3-3212-4ba7-bfbd-4c6fdec40a8e)

# Consul Config (Billing Service) : 
![cons](https://github.com/itsmouhy/AngularSpringEcommerce/assets/100805135/1381a533-5239-4a51-a6d5-c9592b9749fa)

# Vault (Billing Service) :
![vault](https://github.com/itsmouhy/AngularSpringEcommerce/assets/100805135/a788ab39-d105-4db4-9280-22c99b5c172a)






